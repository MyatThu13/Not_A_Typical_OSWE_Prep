#### Imprimir código de barras del ejemplar
<hr>
El menú proporciona una forma de imprimir los códigos de barras de los ejemplares basados en los datos que se han incluido en SLiMS.

#### Menú de impresión de etiquetas 
<hr>
Con este menú se pueden imprimir etiquetas basadas en la colección bibliográfica que se ingresa en SLiMS. La siguiente secuencia imprime dichas etiquetas usando el menú Imprimir etiquetas:

- Haga clic en Imprimir etiquetas, y la pantalla aparecerá como sigue:
- Seleccione la bibliografía a la cual desee imprimir la etiqueta. Utilice Shift + clic para seleccionar más de una casilla de verificación en una secuencia rápida de selección. Nota: una tirada sólo puede contener un máximo de 50 registros. En este menú también es posible imprimir más de una etiqueta, dependiendo de la cantidad de ejemplares que de un título existan.
- Haga clic en Agregar a la cola de impresión para introducir la selección en la cola de impresión.
- Haga clic en Imprimir etiquetas para iniciar la impresión de los datos seleccionados, se le mostrará una ventana popup que le solictará enviar las  etiquetas a la impresora.

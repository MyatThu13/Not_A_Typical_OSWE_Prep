### Préstamos por clasificación

Este es un informe de préstamos basado en la clasificación. Además de las clases 0-9, el informe también hace posible consultar las clases no decimales 2X. Los préstamos pueden ser filtrados por:
- Clase,
- Tipo, y
- Año.

Esta característica también proporciona la facilidad de permitir la descarga de un archivo de hoja de cálculo. Los archivos se pueden obtener haciendo clic en "Exportar a formato de hoja de cálculo".
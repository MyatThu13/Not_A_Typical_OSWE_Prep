#### Devolución rápida

Para realizar una devolución, utilice el código de ID del ejemplar.
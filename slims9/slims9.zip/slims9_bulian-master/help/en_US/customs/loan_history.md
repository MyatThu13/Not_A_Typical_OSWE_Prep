####Loan History

Contains data of every transaction ever undertaken. Resulting data comprises: 
- Member ID, 
- Member Name, 
- Item Code, 
- Title, 
- Loan date, 
- Due date. 

In this menu the facility is also provided to print a list of borrowing history. In addition it is also possible to perform a search of history data. History data search can be done by:
- Member ID/Member Name, 
- Document Title, 
- Item Code, 
- Date From, and 
- Loan Loan Until Date. 

This facility can be displayed by clicking the Show More Filter Options. 

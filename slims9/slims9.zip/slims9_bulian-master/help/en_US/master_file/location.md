####Master File / Location
<hr>
location code and the name of the location where the item is placed
Example: Engineering Faculty Library
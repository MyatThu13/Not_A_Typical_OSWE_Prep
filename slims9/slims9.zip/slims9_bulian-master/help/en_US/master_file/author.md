#### Master File / Author
<hr>
Author's name and the type of author (individual or group)

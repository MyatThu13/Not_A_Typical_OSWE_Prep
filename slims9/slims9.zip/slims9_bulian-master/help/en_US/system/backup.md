###Database Backup

A facility to backup the Senayan database. click Start New Backup and Senayan will back up automatically. The format of backup files created by Senayan is .sql in layout and named according to the creation date and store within directory files/backup.

Note: 
To do this backup, the mysql database user must have the right to LOCK TABLES.

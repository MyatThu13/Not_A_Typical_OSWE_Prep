###Biblio Indexes

This menu is used to index the bibliographic databases used by SLiMS. Given this indexing, the search performance of SLiMS will be improved.

There are three functions in this menu:
- Emptying the index: to clear the existing index results,
- Re-Create Index: to re-index the database of bibliographic data,
- Update the index: to index new bibliographic data that has not yet been indexed.

You can locate setting for index type within config/sysconfig.local.inc.php.

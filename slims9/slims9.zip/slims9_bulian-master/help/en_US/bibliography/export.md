#### Export Data
<hr>
The Export Data menu is used to retrieve bibliographic data in the SLiMS application, to then be included in an application other than Senayan. This process can be understood as a data exchange.
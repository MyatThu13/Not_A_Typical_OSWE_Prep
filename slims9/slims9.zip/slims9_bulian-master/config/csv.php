<?php
return [
    'separator' => ',',
    'enclosed_with' => '"',
    'record_separator' => [
        'newline' => "\n",
        'return' => "\t"
    ]
];
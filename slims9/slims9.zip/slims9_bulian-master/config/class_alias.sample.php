<?php
/**
 * Define your class as global function
 */
return [
  'DB' => \SLiMS\DB::class,
]; // make a short class call

#!/Applications/XAMPP/xamppfiles/bin/php
<?php

?>
